#!/bin/sh

install_dir="/usr/local/cross"

binutils="binutils-2.21.1"
gcc="gcc-3.4.6"
newlib="newlib-1.20.0"
gdb="gdb-7.3.1"

#makeopt="-j 2"
